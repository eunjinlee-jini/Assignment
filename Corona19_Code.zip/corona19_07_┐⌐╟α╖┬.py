'''
    서울시 코로나19 데이터 수집 및 분석

    25. 여행력
'''

import pandas as pd
import numpy as np

file_name = "seoul_corona_10_11_.csv"
df = pd.read_csv(file_name, encoding="utf-8") # 한글처리

# 1. 연번 기준으로 오름차순 정렬
df = df.sort_values(by="연번", ascending=False)
print("1. '연번' 기준으로 오름차순 정렬 : \n", df.head())

# 2. 확진일의 빈도수 (어느 날짜에 가장 많은 확진자가 발생 되었는지 확인)
print("2. 확진일의 빈도수 : \n", df["확진일"].value_counts()) # value_counts() : 자동으로 내림차순 정렬해서 반환 (빈도수)

# 3. '확진일자' 컬럼 추가 ==> 2020-10-11 날짜 형식 변환
# 기존의 '확진일' 컬럼값은 문자이기 때문에 날짜 형식으로 변환
'''
    1) 10.11 --> 10-11 변경
    2) 10-11 --> 2020-10-11 로 변경
    3) 2020-10-11 문자열 --> 2020-10-11 날짜로 변경 (pd.to_datetime 함수)
    4) df["확진일자"] = 날짜
'''
df["확진일자"] = pd.to_datetime("2020-" + df["확진일"].str.replace(".", "-"))
print("3. '확진일자' 컬럼 추가 : \n", df.head())

# 4. '확진일자' 날짜 데이터 컬럼 이용하여 '월(month)' 컬럼 추가
df["월"] = df["확진일자"].dt.month # '확진일자' 에서 월만 출력
print("4. '월' 컬럼 추가 : \n", df.head())

# 5. '확진일자' 날짜 데이터 컬럼 이용하여 '주(week)' 컬럼 추가
# 해당년도의 몇번째 주(week)인지
df["주"] = df["확진일자"].dt.isocalendar().week
print("5. '주(week)' 컬럼 추가 : \n", df.head())

# 6. '확진일자' 날짜 데이터 컬럼 이용하여 '월-일' 컬럼 추가
df["월-일"] = df["확진일자"].astype(str).map(lambda x:x[-5:]) # map 함수 : 데이터 가공시 사용
print("5. '월-일' 컬럼 추가 : \n", df.head())

####################################################################################
# 25. 여행력
print(df["여행력"])
print(df["여행력"].unique())
print(df["여행력"].value_counts())

# 공통명으로 변경
df.loc[df["여행력"].str.contains("아랍에미리트|UAE"), "여행력"] = "아랍에미리트"
df.loc[df["여행력"].str.contains("중국 청도|우한 교민|우한교민|중국 우한시|중국"), "여행력"] = "중국"
df.loc[df["여행력"].str.contains("프랑스, 스페인|스페인, 프랑스"), "여행력"] = "프랑스, 스페인"
df.loc[df["여행력"].str.contains("체코|헝가리|오스트리아|이탈리아|프랑스|모로코|독일|스페인|영국|폴란드|터키|아일랜드"), "여행력"] = "유럽"
df.loc[df["여행력"].str.contains("브라질|아르헨티아|칠레|볼리비아|멕시코|페루"), "여행력"] = "남미"
print(df["여행력"].unique())

# "-"을 np.nan 으로 변경
df["해외"]=df["여행력"]
df["해외"]=df["해외"].replace("-", np.nan)
print(df["해외"].unique())
print(df["해외"].value_counts())

# 상위 15개만 시각화
import matplotlib.pyplot as plt
plt.rc("font", family="Malgun Gothic") # 한글 처리
plt.rc("ytick", labelsize=10) # y측 label 크기
plt.rc("xtick", labelsize=10) # x측 label 크기
plt.style.use("ggplot")
g = df["해외"].value_counts().head(15).sort_values().plot.barh(title="여행력 별 감염경로", figsize=(15, 8))
plt.xlabel("(단위 : 명)") # x축 label
plt.show()






















