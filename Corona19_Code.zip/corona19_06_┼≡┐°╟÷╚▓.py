'''
    서울시 코로나19 데이터 수집 및 분석

    24. 퇴원 현황
'''

import pandas as pd
import numpy as np

file_name = "seoul_corona_10_11_.csv"
df = pd.read_csv(file_name, encoding="utf-8") # 한글처리

# 1. 연번 기준으로 오름차순 정렬
df = df.sort_values(by="연번", ascending=False)
print("1. '연번' 기준으로 오름차순 정렬 : \n", df.head())

# 2. 확진일의 빈도수 (어느 날짜에 가장 많은 확진자가 발생 되었는지 확인)
print("2. 확진일의 빈도수 : \n", df["확진일"].value_counts()) # value_counts() : 자동으로 내림차순 정렬해서 반환 (빈도수)

# 3. '확진일자' 컬럼 추가 ==> 2020-10-11 날짜 형식 변환
# 기존의 '확진일' 컬럼값은 문자이기 때문에 날짜 형식으로 변환
'''
    1) 10.11 --> 10-11 변경
    2) 10-11 --> 2020-10-11 로 변경
    3) 2020-10-11 문자열 --> 2020-10-11 날짜로 변경 (pd.to_datetime 함수)
    4) df["확진일자"] = 날짜
'''
df["확진일자"] = pd.to_datetime("2020-" + df["확진일"].str.replace(".", "-"))
print("3. '확진일자' 컬럼 추가 : \n", df.head())

# 4. '확진일자' 날짜 데이터 컬럼 이용하여 '월(month)' 컬럼 추가
df["월"] = df["확진일자"].dt.month # '확진일자' 에서 월만 출력
print("4. '월' 컬럼 추가 : \n", df.head())

# 5. '확진일자' 날짜 데이터 컬럼 이용하여 '주(week)' 컬럼 추가
# 해당년도의 몇번째 주(week)인지
df["주"] = df["확진일자"].dt.isocalendar().week
print("5. '주(week)' 컬럼 추가 : \n", df.head())

# 6. '확진일자' 날짜 데이터 컬럼 이용하여 '월-일' 컬럼 추가
df["월-일"] = df["확진일자"].astype(str).map(lambda x:x[-5:]) # map 함수 : 데이터 가공시 사용
print("5. '월-일' 컬럼 추가 : \n", df.head())

####################################################################################
# 24. 퇴원 현황
print(df["퇴원현황"])
print(df["퇴원현황"].unique())
print(df["퇴원현황"].value_counts())

# NaN ==> "치료중" 으로 변경
df["퇴원현황"].fillna('치료중', inplace=True) # inplace=True : 자기 자신이 변경
print("퇴원현황 빈도수 : \n", df["퇴원현황"].value_counts())

# 퇴원현황 시각화
import matplotlib.pyplot as plt

plt.rc("font", family="Malgun Gothic") # 한글 처리
plt.rc("ytick", labelsize=10) # y측 label 크기
plt.rc("xtick", labelsize=10) # x측 label 크기
plt.style.use("ggplot")
df["퇴원현황"].value_counts().sort_values().plot.barh(title="퇴원 현황", figsize=(6, 4))
plt.xlabel("(단위 : 명)") # x축 label
plt.show()
























