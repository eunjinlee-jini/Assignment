'''
    서울시 코로나19 데이터 수집 및 분석

    18. '거주지' 별 확진자의 빈도수 확인 및 막대 그래프(barh) 시각화
    19. 서울 지역 추출 및 시각화 (서울시 25개구만 출력)
'''

import pandas as pd
import numpy as np

file_name = "seoul_corona_10_11_.csv"
df = pd.read_csv(file_name, encoding="utf-8") # 한글처리

# 1. 연번 기준으로 오름차순 정렬
df = df.sort_values(by="연번", ascending=False)
print("1. '연번' 기준으로 오름차순 정렬 : \n", df.head())

# 2. 확진일의 빈도수 (어느 날짜에 가장 많은 확진자가 발생 되었는지 확인)
print("2. 확진일의 빈도수 : \n", df["확진일"].value_counts()) # value_counts() : 자동으로 내림차순 정렬해서 반환 (빈도수)

# 3. '확진일자' 컬럼 추가 ==> 2020-10-11 날짜 형식 변환
# 기존의 '확진일' 컬럼값은 문자이기 때문에 날짜 형식으로 변환
'''
    1) 10.11 --> 10-11 변경
    2) 10-11 --> 2020-10-11 로 변경
    3) 2020-10-11 문자열 --> 2020-10-11 날짜로 변경 (pd.to_datetime 함수)
    4) df["확진일자"] = 날짜
'''
df["확진일자"] = pd.to_datetime("2020-" + df["확진일"].str.replace(".", "-"))
print("3. '확진일자' 컬럼 추가 : \n", df.head())

# 4. '확진일자' 날짜 데이터 컬럼 이용하여 '월(month)' 컬럼 추가
df["월"] = df["확진일자"].dt.month # '확진일자' 에서 월만 출력
print("4. '월' 컬럼 추가 : \n", df.head())

# 5. '확진일자' 날짜 데이터 컬럼 이용하여 '주(week)' 컬럼 추가
# 해당년도의 몇번째 주(week)인지
df["주"] = df["확진일자"].dt.isocalendar().week
print("5. '주(week)' 컬럼 추가 : \n", df.head())

# 6. '확진일자' 날짜 데이터 컬럼 이용하여 '월-일' 컬럼 추가
df["월-일"] = df["확진일자"].astype(str).map(lambda x:x[-5:]) # map 함수 : 데이터 가공시 사용
print("5. '월-일' 컬럼 추가 : \n", df.head())

####################################################################################
# 18. '거주지' 별 확진자의 빈도수 확인 및 막대 그래프(barh) 시각화
# '거주지' 별 확진자의 빈도수 확인
gu_count = df['거주지'].value_counts()
print("'거주지' 별 확진자의 빈도수 확인 : \n", gu_count)
# (인덱스)      컬럼
#  관악구       417
#  송파구       350
#  성북구       335
#  타시도       322

# '거주지' 별 확진자의 빈도수 확인 및 시각화
import matplotlib.pyplot as plt

# plt.rc("font", family="Malgun Gothic") # 한글 처리
# # plt.rc("figure", titlesize=4) # title 크기
# plt.rc("ytick", labelsize=12) # y측 라벨 크기
# plt.rc("xtick", labelsize=12) # x측 라벨 크기
# plt.style.use("fivethirtyeight") # 스타일 예쁘게
# gu_count.plot.barh(figsize=(15, 8)) # barh : 가로 막대 그래프, bar : 세로 막대 그래프
# plt.show()

# 19. 서울 지역 추출 및 시각화 (서울시 25개구만 출력)
seoul_gu_count = gu_count.index[~gu_count.index.isin(['한국', '기타', '타시도'])] # ~ : 부정, isin : 한국 또는 기타 또는 타시도
print(seoul_gu_count)
seoul_gu_count = gu_count[seoul_gu_count]
print("서울 지역만 추출 : \n", seoul_gu_count)

# 추출된 데이터로 시각화
plt.rc("font", family="Malgun Gothic") # 한글 처리
plt.rc("ytick", labelsize=12) # y측 label 크기
plt.rc("xtick", labelsize=12) # x측 label 크기
plt.style.use("ggplot")
g = seoul_gu_count.head(15).sort_values().plot.barh(title="서울 지역 확진자 수", figsize=(15, 8)) # sort로 정렬, head(20)으로 상위 20개만 노출
plt.xlabel("(단위 : 명)") # x축 label
plt.show()














